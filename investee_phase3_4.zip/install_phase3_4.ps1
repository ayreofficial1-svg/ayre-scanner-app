param([string]$Zip = "investee_phase3_4.zip")
if (-not (Test-Path "pubspec.yaml")) { Write-Host "Run from the project root (pubspec.yaml not found)."; exit 1 }
if (-not (Test-Path $Zip)) { $Zip = Join-Path $PSScriptRoot "investee_phase3_4.zip" }
if (-not (Test-Path $Zip)) { Write-Host "ZIP not found: pass its path as -Zip."; exit 1 }
$root = (Get-Location).Path
$tmp = Join-Path ([IO.Path]::GetTempPath()) ("investee_" + [guid]::NewGuid())
Expand-Archive -Path $Zip -DestinationPath $tmp
$bk = Join-Path $root (".phase_backups\phase3_4_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
Get-ChildItem $tmp -Recurse -File | Where-Object { $_.Name -notlike "install_phase3_4.*" -and $_.Name -ne "FILE_LIST.md" } | ForEach-Object {
  $rel = $_.FullName.Substring($tmp.Length + 1)
  $dest = Join-Path $root $rel
  if (Test-Path $dest) { $b = Join-Path $bk $rel; New-Item -ItemType Directory -Force -Path (Split-Path $b) | Out-Null; Copy-Item $dest $b }
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item $_.FullName $dest -Force
  Write-Host "wrote $rel"
}
Remove-Item $tmp -Recurse -Force
