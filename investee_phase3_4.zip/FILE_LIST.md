# Phase 3+4 file list

| ZIP path | Destination in project |
|---|---|
| investee_branding_and_theme_overhaul_plan.md | investee_branding_and_theme_overhaul_plan.md |
| lib/legal/legal_config.dart | lib/legal/legal_config.dart |
| lib/legal/legal_content.dart | lib/legal/legal_content.dart |
| lib/main.dart | lib/main.dart |
| lib/screens/delete_account_screen.dart | lib/screens/delete_account_screen.dart |
| lib/screens/home_tab.dart | lib/screens/home_tab.dart |
| lib/screens/legal_hub_screen.dart | lib/screens/legal_hub_screen.dart |
| lib/screens/register_screen.dart | lib/screens/register_screen.dart |
| lib/screens/settings_screen.dart | lib/screens/settings_screen.dart |
| lib/screens/splash_screen.dart | lib/screens/splash_screen.dart |
| lib/widgets/ayre_hills.dart | lib/widgets/ayre_hills.dart |
| lib/widgets/ayre_insight_carousel.dart | lib/widgets/ayre_insight_carousel.dart |
| lib/widgets/ayre_instrument_tile.dart | lib/widgets/ayre_instrument_tile.dart |
| lib/widgets/ayre_logo.dart | lib/widgets/ayre_logo.dart |
| pubspec.yaml | pubspec.yaml |

Install: run `install_phase3_4.sh` or `install_phase3_4.ps1` from the project root, with `investee_phase3_4.zip` in that folder (or passed as an argument).
Manual: copy each file to its destination (same relative path); back up originals first.
