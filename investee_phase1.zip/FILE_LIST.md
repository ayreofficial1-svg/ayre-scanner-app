# Phase 1 file list

| ZIP path | Destination in project |
|---|---|
| lib/theme/app_theme.dart | lib/theme/app_theme.dart |
| lib/main.dart | lib/main.dart |
| investee_branding_and_theme_overhaul_plan.md | investee_branding_and_theme_overhaul_plan.md |

Install: run `install_phase1.sh` (macOS/Linux/Git-Bash) or `install_phase1.ps1` (PowerShell) from the project root (folder with `pubspec.yaml`).
Manual: copy each file above to its destination (same relative path); back up originals first.
