# Phase 5 file list

| ZIP path | Destination in project |
|---|---|
| android/app/src/main/AndroidManifest.xml | android/app/src/main/AndroidManifest.xml |
| android/app/src/main/kotlin/com/example/ayre_scanner/MainActivity.kt | android/app/src/main/kotlin/com/example/ayre_scanner/MainActivity.kt |
| android/app/src/main/res/values/colors.xml | android/app/src/main/res/values/colors.xml |
| investee_branding_and_theme_overhaul_plan.md | investee_branding_and_theme_overhaul_plan.md |
| ios/Runner/Info.plist | ios/Runner/Info.plist |
| linux/runner/my_application.cc | linux/runner/my_application.cc |
| macos/Runner/Info.plist | macos/Runner/Info.plist |
| web/index.html | web/index.html |
| web/manifest.json | web/manifest.json |
| windows/runner/Runner.rc | windows/runner/Runner.rc |
| windows/runner/main.cpp | windows/runner/main.cpp |

Install: run `install_phase5.sh` or `install_phase5.ps1` from the project root, with `investee_phase5.zip` in that folder (or passed as an argument).
Manual: copy each file to its destination (same relative path); back up originals first.
