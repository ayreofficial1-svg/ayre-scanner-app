#!/usr/bin/env bash
set -e
[ -f pubspec.yaml ] || { echo "Run from the project root (pubspec.yaml not found)."; exit 1; }
ROOT="$(pwd)"
ZIP="${1:-$ROOT/investee_phase5.zip}"
[ -f "$ZIP" ] || { echo "ZIP not found: pass its path as the first argument."; exit 1; }
TMP="$(mktemp -d)"; unzip -q "$ZIP" -d "$TMP"
BK="$ROOT/.phase_backups/phase5_$(date +%Y%m%d_%H%M%S)"
( cd "$TMP" && find . -type f ! -name 'install_phase5.*' ! -name 'FILE_LIST.md' | sed 's|^\./||' ) | while read -r f; do
  if [ -f "$ROOT/$f" ]; then mkdir -p "$BK/$(dirname "$f")"; cp "$ROOT/$f" "$BK/$f"; fi
  mkdir -p "$ROOT/$(dirname "$f")"; cp "$TMP/$f" "$ROOT/$f"; echo "wrote $f"
done
rm -rf "$TMP"
