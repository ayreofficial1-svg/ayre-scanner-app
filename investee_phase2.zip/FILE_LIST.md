# Phase 2 file list

| ZIP path | Destination in project |
|---|---|
| lib/widgets/ayre_components.dart | lib/widgets/ayre_components.dart |
| lib/widgets/ayre_sheet.dart | lib/widgets/ayre_sheet.dart |
| lib/widgets/onboarding_widgets.dart | lib/widgets/onboarding_widgets.dart |
| lib/widgets/spotlight_tour.dart | lib/widgets/spotlight_tour.dart |
| lib/widgets/ayre_avatar.dart | lib/widgets/ayre_avatar.dart |
| investee_branding_and_theme_overhaul_plan.md | investee_branding_and_theme_overhaul_plan.md |

Install: run `install_phase2.sh` or `install_phase2.ps1` from the project root (folder with `pubspec.yaml`), with `investee_phase2.zip` in that folder or passed as an argument.
Manual: copy each file to its destination (same relative path); back up originals first.
